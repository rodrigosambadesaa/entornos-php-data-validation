<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/src/RegistrationValidator.php';

function h(string $value): string { return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function old(string $key): string { return h((string)($_POST[$key] ?? '')); }
function checked(string $topic): string { return in_array($topic, (array)($_POST['temas'] ?? []), true) ? ' checked' : ''; }
function selected(string $key, string $value): string { return (string)($_POST[$key] ?? '') === $value ? ' selected' : ''; }

$errors = [];
$submitted = $_SERVER['REQUEST_METHOD'] === 'POST';
if ($submitted) {
    $errors = RegistrationValidator::validate($_POST);
}
$success = $submitted && $errors === [];
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Práctica modernizada de validación de datos con HTML5 y PHP.">
  <title>Formulario de registro</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
<main class="container">
  <header>
    <p class="eyebrow">Entornos de Desarrollo · práctica modernizada</p>
    <h1>Formulario de registro</h1>
    <p>Validación HTML5 en el cliente y validación autoritativa en PHP en el servidor.</p>
  </header>

  <?php if ($success): ?>
    <section class="notice success" aria-live="polite">
      <h2>Datos correctos</h2>
      <p>El formulario cumple todas las reglas de la práctica.</p>
      <a href="index.php">Enviar otro formulario</a>
    </section>
  <?php elseif ($submitted): ?>
    <section class="notice error" aria-live="assertive">
      <h2>Revisa los siguientes campos</h2>
      <ul><?php foreach ($errors as $message): ?><li><?= h($message) ?></li><?php endforeach; ?></ul>
    </section>
  <?php endif; ?>

  <?php if (!$success): ?>
  <form method="post" action="index.php" novalidate>
    <fieldset>
      <legend>Datos de identificación</legend>
      <label>Correo electrónico <span aria-hidden="true">*</span>
        <input type="email" name="correo" value="<?= old('correo') ?>" minlength="5" maxlength="320" autocomplete="email" required>
      </label>
      <label>Contraseña <span aria-hidden="true">*</span>
        <input type="password" name="clave" minlength="4" maxlength="20" autocomplete="new-password" required>
      </label>
      <label>Repita contraseña <span aria-hidden="true">*</span>
        <input type="password" name="clave_repe" minlength="4" maxlength="20" autocomplete="new-password" required>
      </label>
      <label>Nombre y apellidos <span aria-hidden="true">*</span>
        <input type="text" name="nombre" value="<?= old('nombre') ?>" minlength="3" maxlength="80" autocomplete="name" required>
      </label>
    </fieldset>

    <fieldset>
      <legend>Dirección</legend>
      <label>Calle <span aria-hidden="true">*</span><input type="text" name="calle" value="<?= old('calle') ?>" minlength="5" maxlength="40" autocomplete="street-address" required></label>
      <label>Número <span aria-hidden="true">*</span><input type="number" name="numero" value="<?= old('numero') ?>" min="1" step="1" inputmode="numeric" required></label>
      <label>Piso <input type="text" name="piso" value="<?= old('piso') ?>" maxlength="20"></label>
      <label>Población <span aria-hidden="true">*</span><input type="text" name="poblacion" value="<?= old('poblacion') ?>" minlength="3" maxlength="40" autocomplete="address-level2" required></label>
      <label>Provincia <span aria-hidden="true">*</span>
        <select name="provincia" autocomplete="address-level1" required>
          <option value="">Seleccione…</option>
          <option value="1"<?= selected('provincia','1') ?>>A Coruña</option>
          <option value="2"<?= selected('provincia','2') ?>>Lugo</option>
          <option value="3"<?= selected('provincia','3') ?>>Ourense</option>
          <option value="4"<?= selected('provincia','4') ?>>Pontevedra</option>
        </select>
      </label>
      <label>Código postal <span aria-hidden="true">*</span><input type="text" name="codigo_postal" value="<?= old('codigo_postal') ?>" pattern="[0-9]{5}" maxlength="5" inputmode="numeric" autocomplete="postal-code" required></label>
    </fieldset>

    <fieldset>
      <legend>Datos personales</legend>
      <label>Estado civil <span aria-hidden="true">*</span>
        <select name="estado_civil" required>
          <option value="">Seleccione…</option>
          <option value="c"<?= selected('estado_civil','c') ?>>Casada/o</option>
          <option value="s"<?= selected('estado_civil','s') ?>>Soltera/o</option>
          <option value="v"<?= selected('estado_civil','v') ?>>Viuda/o</option>
        </select>
      </label>
      <label>Fecha de nacimiento <span aria-hidden="true">*</span><input type="date" name="fecha_nacimiento" value="<?= old('fecha_nacimiento') ?>" required></label>
      <label>Página web <input type="url" name="web" value="<?= old('web') ?>" placeholder="https://ejemplo.com"></label>
    </fieldset>

    <fieldset>
      <legend>Temas de interés <span aria-hidden="true">*</span></legend>
      <div class="checks">
      <?php foreach (['Música','Deportes','Lectura','Cine','Teatro','Coches','Estética','Móviles','Viajes'] as $topic): ?>
        <label><input type="checkbox" name="temas[]" value="<?= h($topic) ?>"<?= checked($topic) ?>> <?= h($topic) ?></label>
      <?php endforeach; ?>
      </div>
    </fieldset>
    <p class="required"><span aria-hidden="true">*</span> Datos obligatorios</p>
    <div class="actions"><button type="submit">Enviar</button><button type="reset" class="secondary">Borrar datos</button></div>
  </form>
  <?php endif; ?>
</main>
</body>
</html>
