# Entornos de Desarrollo — Validación de datos

Modernización de la práctica de 2018 de validación de un formulario de registro.

## Qué se conserva

Se mantienen las reglas académicas del ejercicio: correo, contraseña y repetición, nombre, dirección, provincia gallega, código postal, estado civil, fecha de nacimiento, web opcional y al menos un tema de interés.

## Qué se moderniza

- Formulario semántico HTML5 en lugar de tablas de maquetación y `<font>`.
- Tipos `email`, `number`, `date` y `url`, `required`, `minlength`, `maxlength` y `pattern`.
- PHP moderno con `declare(strict_types=1)` y acceso explícito a `$_POST`; se elimina `extract($_POST)`.
- La validación del servidor queda aislada y testeable.
- Todas las salidas dinámicas se escapan con `htmlspecialchars`.
- Diseño responsive y accesible.

La entrega de 2018 se conserva sin modificar en `legacy/`.

## Ejecutar

```bash
php -S 127.0.0.1:8000 -t public
```

Abra `http://127.0.0.1:8000`.

## Tests

```bash
php -l src/RegistrationValidator.php
php -l public/index.php
php tests/run.php
```
